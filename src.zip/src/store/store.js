// src/store.js или src/store/index.js
import { createStore } from 'vuex';

export default createStore({
  state: {
    // ваше состояние здесь
  },
  mutations: {
    // ваши мутации здесь
  },
  actions: {
    // ваши действия здесь
  },
  getters: {
    // ваши геттеры здесь
  }
});
