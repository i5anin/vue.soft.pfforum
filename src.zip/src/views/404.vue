<!-- src/views/Home.vue -->
<template>
  <div>
    <h1>Нет такой страницы 404</h1>
  </div>
</template>

<script>
export default {
  name: 'Error404',
};
</script>
