<!-- src/views/Home.vue -->
<template>
  <div>
    <h1>Home Page</h1>
    <h1>Home Page</h1>
    <h1>Home Page</h1>
  </div>
</template>

<script>
export default {
  name: 'Home',
};
</script>
